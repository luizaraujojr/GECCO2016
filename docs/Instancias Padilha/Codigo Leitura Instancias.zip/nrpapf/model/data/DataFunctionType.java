package br.unirio.nrpapf.model.data;

/**
 * Enumeration for the types of data functions
 *  
 * @author Marcio Barros
 */
public enum DataFunctionType 
{
	 EIF,
	 ILF
}